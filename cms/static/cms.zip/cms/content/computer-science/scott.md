title: Scott's notes
extra_style:
  - "body{font-size: 2px;}"
---
### Intro powerpoint:

- 50% Exam
- 50% Coursework:
    - 25% Autumn - Week 8
    - 25% Spring - Week 6

### Topics Autumn:
- Introduction to networks (3)
- LAN vs WAN, management protocols, components (2)
- Internetworking standards: TCP/IP, UDP/IP, IPv4, IPv6 (9)
- Applications: emails, DNS, multimedia (4)
- Network Security (3)

### What is a network?:
- Composed of a number of units: routers, switches, bridges, gateways
- Established with physical technologies: fibre, twisted pair, wireless
- Can be distinguished based on geographical span: LAN, WAN, MAN etc.
- They enable SOFTWARE units to COMMUNICATE and exchange infomation

### What can you do on it?:
- File Transfer (ftp, ncftp)
- Remote Terminals (rlogin, telnet)
- Remote Execution (rsh)
- Remote Printing (lpc, lpr)
- Email and Web (mail, elm, pine, thunderbird)

### Examples:
- Distributed File System:
    - Files appear local on machime but are actually stored on a server
    - In Unix NFS, the details of which physical disk contains the file can be hidden

- Distributed Windows System:
    - Input taken from user terminal, processing done at a remote server e.g VNC, Windows Remote Desktop
    - X-Windows system - local host displays windows, text and graphics on behalf of the remote app.

### Client-Server model:
- Netwoks are either Peer-to-peer or Client-Server
- In Client-Server, functionality is split between the service provider (server) and the user (client) e.g mail server, web server, print server
- A server must be able to process mutiple requests simultaneously. They can offer a single service or provide many at the same time

### Protocols:
- Defines a set of RULES for COMMUNICATION between two or more entities
- Need different protcols for different things so there is a PROTOCOL STACK that has layers of protocols.
- OSI 7 Layer Protocol stack:
    - Application
    - Presentation
    - Session
    - Transport
    - Network
    - Data Link
    - Physical