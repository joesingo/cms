title: Limits of multivariable functions
base_config: content/maths/index.md
---
Let us start off by looking at the definition of the limit of a single-variable
function. If \\(A\subseteq \R\\) and \\(x_0\\) is a cluster point of \\(A\\),
we say a function \\(f:A \to \R\\)
has a *limit*
\\(L\in\R\\)
at \\(x_0\\) if for all \\(\epsilon>0\\) there exists \\(\delta>0\\)
such that whenever \\(0<|x-x_0|<\delta\\), we have \\(|f(x)-L|<\epsilon\\). In
this case we write \\(\lim_{x\to x_0}f(x)=L\\).

The idea behind this definition is that we can make \\(f(x)\\) arbitrarily close
to \\(L\\) by taking \\(x\\) close enough to \\(x_0\\). When it comes to defining
the limit of a function from \\(\R^n\\) to \\(\R\\) we can use the
same approach, and require that \\(f(\bold{x})\\) is close to \\(L\\) when the
[Euclidean distance](/maths/calculus/glossary#euc-distance) between \\(\bold{x}\\) and \\(\bold{x_0}\\) is small enough. In other words, we require that \\(f(\bold{x})\\)
is close to \\(L\\) when \\(\bold{x}\\) is in a [\\(\delta\\)-neighbourhood](/maths/calculus/glossary#d-neighbhd) of \\(x_0\\) for a suitably small \\(\delta\\).

The full definition is as follows:

<def>
    <def-title>Definition: Limit of a function</def-title>
    <def-body>
        Let \(A \subseteq \R^n\) and let \(f\) be a function \(f: A \to \R^n\). We say
        that the limit of \(f\) at a point \(\bold{x_0} \in \R^n \) is the real number \(L\)
        if for any \(\epsilon > 0\) there exists \(\delta > 0 \) such that for all
        \(\bold{x} \in U_{\delta}(\bold{x_0}) \backslash \{\bold{x_0}\} \), we have \( | f(\bold{x})-L | < \epsilon\)
    </def-body>
</def>

In fact, this isn't really any different from the definition for one variable,
since the Euclidean distance between \\(x\\) and \\(x_0\\) in \\(\R\\) is
\\(\sqrt{(x-x_0)^2}=|x-x_0|\\).