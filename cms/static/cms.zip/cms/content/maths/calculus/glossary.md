title: Glossary - Multivariable calculus
base_config: content/maths/index.md
    ---
<def>
<def-title><span id="euc-distance">Euclidean distance</span></def-title>

<def-body>
The Euclidean distance between two points \(\mathbf{x}=(x_1,\ldots,x_n)\) and
\(\mathbf{y}=(y_1,\ldots,y_n)\) in \(\mathbb{R}^n\) is defined as

\[ \|\mathbf{x}-\mathbf{y}\|=\sqrt{\sum_{i=1}^{n}{(x_i-y_i)^2}}=
    \sqrt{(x_1-y_1)^2+\ldots+(x_n-y_n)^2} \]

<b>Example:</b> The distance between \(\mathbf{x}=(1,4,3,6)\) and
\(\mathbf{y}=(5,1,-4,-10)\) in \(\mathbb{R}^4\) is

\[
    \|\mathbf{x}-\mathbf{y}\| =\sqrt{(1-5)^2+(4-1)^2+(3+4)^2+(6+10)^2}=\sqrt{330}
\]
</def-body>
</def>

<def>
<def-title><span id="d-neighbhd">\(\delta\)-neighbourhood</span></def-title>

<def-body>
Given a point \(\mathbf{x} \in \mathbb{R}^n\) and \(\delta>0\), the
\(\delta\)-neighbourhood of \(\mathbf{x}\) is the set
\[
    U_{\delta}(\mathbf{x})=\{\mathbf{y} \in \Bbb{R}^n : \|\mathbf{x}-\mathbf{y}\|<\delta\}
\]
In other words, it is the set of all other points whose distance from \(\mathbf{x}\)
is less than \(\delta\). In \(\Bbb{R}\) this will be an interval, in \(\Bbb{R}^2\)
a disc, and in \(\Bbb{R}^3\) a ball.
</def-body>
</def>