js_scripts:
  - "https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML"

custom_elements:
    def: "<div class='def panel panel-default'>$</div>"
    def-title: "<div class='panel-heading'>$</div>"
    def-body: "<div class='panel-body'>$</div>"

extra_body:
  - >
      \(
      \def\R{\mathbb{R}}
      \def\bold#1{\mathbf #1}
      \)

---
